import mongoose from "mongoose";

const { Schema } = mongoose;

/**
 * 🔹 Sub-schema for supervisor details
 */
const SupervisorDetailsSchema = new Schema(
  {
    supervisorId: { type: Schema.Types.ObjectId, ref: "Supervisor" },
    comments: { type: String, trim: true },
    images: [{ type: String }],
  },
  { _id: false }
);

/**
 * 🔹 Sub-schema for material demand
 */
const MaterialDemandSchema = new Schema(
  {
    materialName: { type: Schema.Types.ObjectId, required: true, ref: 'StockIn' },
    category: { type: Schema.Types.ObjectId, ref: 'Category' },
    subCategory: { type: Schema.Types.ObjectId, ref: 'SubCategory' },
    quantity: { type: String, required: true, trim: true },
    reason: { type: String, trim: true },
    images: [{ type: String }],
  },
  { _id: false }
);

/**
 * 🔹 Sub-schema for resolution details
 */
const ResolutionSchema = new Schema(
  {
    resolvedBy: { type: Schema.Types.ObjectId, ref: "User" },
    remarks: { type: String, trim: true },
    images: [{ type: String }],
    resolvedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);
const ClosureDetailsSchema = new Schema(
  {
    closedBy: { type: Schema.Types.ObjectId, ref: "User" },
    remarks: { type: String, trim: true },
    images: [{ type: String }],
    closedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);
/**
 * 🔹 Sub-schema for repush details
 */
const RepushedDetailsSchema = new Schema(
  {
    count: { type: Number, default: 1 },
    reason: { type: String, trim: true },
    repushedAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

/**
 * 🔹 Sub-schema for each status history entry
 */
const StatusHistorySchema = new Schema(
  {
    status: {
      type: String,
      enum: [
        "Open",
        "Review By Supervisor",
        "Raise Material Demand",
        "Work in Progress",
        "Closed By Supervisor",
        "Repush By Help Desk",
        "Closed By Help Desk",
      ],
    },
    updatedBy: { type: Schema.Types.ObjectId, ref: "User" },
    updatedByRole: {
      type: String,
      enum: ["Admin", "Supervisor", "Landlord", "Tenant"],
    },
    comment: { type: String, trim: true },
    supervisorDetails: SupervisorDetailsSchema,
    materialDemand: MaterialDemandSchema,
    resolution: ResolutionSchema,
    closureDetails: ClosureDetailsSchema,
    // closedBy: { type: Schema.Types.ObjectId, ref: "User" },
    // closedImages: [{ type: String }],
    repushedDetails: RepushedDetailsSchema,
    updatedAt: { type: Date, default: Date.now },
  },
  { _id: true }
);

/**
 * 🔹 Main Complaint Schema
 */
const ComplaintSchema = new Schema(
  {
    siteId: { type: Schema.Types.ObjectId, ref: "Site", required: true },
    // projectId: { type: Schema.Types.ObjectId, ref: "Project", required: true },
    unitId: { type: Schema.Types.ObjectId, ref: "Unit", required: true },
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
    addedBy: {
      type: String,
      enum: ["Landlord", "Tenant", "Admin"],
      required: true,
    },
    complaintTitle: { type: String, required: true, trim: true },
    problemType: { type: String, required: true, trim: true },
    complaintDescription: { type: String, required: true, trim: true },
    images: [{ type: String }],

    // 🔹 Current status
    status: {
      type: String,
      enum: [
        "Open",
        "Review By Supervisor",
        "Raise Material Demand",
        "Work in Progress",
        "Closed By Supervisor",
        "Repush By Help Desk",
        "Closed By Help Desk",
      ],
      default: "Open",
    },

    // 🔹 Full status history
    statusHistory: [StatusHistorySchema],
    buzzer: {
      isActive: { type: Boolean, default: false }, // is buzzer currently ringing?
      autoTriggerAt: { type: Date }, // when buzzer should start
      disabledByUser: { type: Boolean, default: false }, // user manually stopped buzzer
    },
  },
  { timestamps: true }
);

const Complaint =
  mongoose.models.Complaint || mongoose.model("Complaint", ComplaintSchema);

export default Complaint;
