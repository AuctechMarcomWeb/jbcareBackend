import mongoose from "mongoose";

const LedgerSchema = new mongoose.Schema(
  {
    landlordId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Landlord",
      required: true,
    },
    tenantId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Tenant",
      required: true,
    },
    siteId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Site",
      required: true,
    },
    unitId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Unit",
      required: true,
    },
    type: {
      type: String,
    },

    // Bill ID (optional)
    billId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Billing",
      default: null,
    },

    purpose: { type: String, trim: true },

    amount: { type: Number, default: 0 },
    // Balance tracking
    // 🆕 Opening Balance with debit/credit type
    openingBalance: {
      amount: { type: Number, default: 0 }, // Opening balance
      type: {
        type: String,
        enum: ["Debit", "Credit", null], // Debit = pending, Credit = advance
        default: null,
      },
    },
    closingBalance: {
      amount: { type: Number, default: 0 },
      type: { type: String, enum: ["Debit", "Credit", null], default: null },
    },
    transactionType: {
      type: String,
      enum: ["Bill", "Payment", "Opening Balance"],
    },
    paymentMode: {
      type: String
    },
    createdAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

export default mongoose.model("Ledger", LedgerSchema);
