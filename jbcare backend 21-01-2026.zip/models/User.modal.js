import mongoose from "mongoose";
import bcrypt from "bcryptjs";

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      trim: true,
    },
    email: {
      type: String,
      lowercase: true,
      match: [/^\S+@\S+\.\S+$/, "Please enter a valid email address"],
    },
    phone: {
      type: String,
      match: [/^[0-9]{10}$/, "Phone number must be 10 digits"],
    },
    gender: {
      type: String,
      enum: ["Male", "Female", "Other"],
    },
    address: {
      type: String,
      trim: true,
    },
    role: {
      type: String,
      enum: ["admin", "user", "supervisor", "landlord", "tenant"],
      default: "user",
    },
    profilePic: {
      type: String
    },
    password: {
      type: String,
      required: [true, "Password is required"],

    },
    referenceId: { type: mongoose.Schema.Types.ObjectId },
    siteId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Site",
    },
    projectId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Project",
    },
    unitId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Unit",
    },
    fcmToken: {
      type: String,
    },
    resetPasswordOTP: { type: String },
    resetPasswordExpires: { type: Date },
  },
  {
    timestamps: true,
  }
);



userSchema.index({ email: 1 });
userSchema.index({ siteId: 1 });
userSchema.index({ projectId: 1 });
userSchema.index({ unitId: 1 });
userSchema.index({ referenceId: 1 });

const User = mongoose.model("User", userSchema);
export default User;
