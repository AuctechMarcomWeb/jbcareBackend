import Tenant from "../models/Tenant.modal.js";
import Landlord from "../models/LandLord.modal.js";
import User from "../models/User.modal.js";
import Unit from "../models/masters/Unit.modal.js";
import { sendError, sendSuccess } from "../utils/responseHandler.js";
import Site from "../models/masters/site.modal.js";
import Project from "../models/masters/Project.modal.js";
import { createUser } from "../utils/createUser.js";

export const addTenant = async (req, res) => {
  try {
    const {
      name,
      phone,
      email,
      address,
      profilePic,
      siteId,
      unitId,
      landlordId,
      addedBy,
      billTo,
      gender,
      dob,
      idProof,
      isActive = true,
      parking,
    } = req.body;

    // -----------------------------
    // 🔴 REQUIRED FIELD VALIDATION
    // -----------------------------
    const missingFields = [];
    if (!name) missingFields.push("name");
    if (!phone) missingFields.push("phone");
    if (!siteId) missingFields.push("siteId");
    if (!unitId) missingFields.push("unitId");
    if (!landlordId) missingFields.push("landlordId");
    if (!addedBy) missingFields.push("addedBy");

    if (missingFields.length) {
      return sendError(
        res,
        `Missing required field(s): ${missingFields.join(", ")}`,
        400
      );
    }

    // if (!/^[6-9]\d{9}$/.test(phone)) {
    //   return sendError(res, "Invalid phone number format", 400);
    // }

    // if (email && !/^\S+@\S+\.\S+$/.test(email)) {
    //   return sendError(res, "Invalid email format", 400);
    // }


    const existingTenant = await Tenant.findOne({
      isActive: true,
      $or: [{ phone }, ...(email ? [{ email }] : [])],
    });

    if (existingTenant) {
      return sendError(
        res,
        "Active tenant with this phone or email already exists",
        409
      );
    }

    // -----------------------------
    // 🔍 DUPLICATE CHECK — USER
    // -----------------------------
    const existingUser = await User.findOne({
      $or: [{ phone }, ...(email ? [{ email }] : [])],
    });

    if (existingUser) {
      return sendError(
        res,
        "User with this phone or email already exists",
        409
      );
    }

    // -----------------------------
    // 🏠 LANDLORD & UNIT VALIDATION
    // -----------------------------
    const landlord = await Landlord.findById(landlordId);
    if (!landlord || !landlord.isActive) {
      return sendError(res, "Landlord not found or inactive", 404);
    }

    const unit = await Unit.findById(unitId);
    if (!unit) {
      return sendError(res, "Unit not found", 404);
    }

    if (String(unit.landlordId) !== String(landlordId)) {
      return sendError(
        res,
        "This unit does not belong to the given landlord",
        400
      );
    }

    // -----------------------------
    // 🔄 DEACTIVATE OTHER ACTIVE TENANTS
    // -----------------------------
    if (isActive) {
      const otherTenants = await Tenant.find({ unitId, isActive: true });

      for (const other of otherTenants) {
        other.isActive = false;
        other.tenancyEndDate = new Date();
        await other.save();

        const historyEntry = unit.tenantHistory.find(
          h =>
            String(h.tenantId) === String(other._id) &&
            h.isActive === true
        );

        if (historyEntry) {
          historyEntry.endDate = other.tenancyEndDate;
          historyEntry.isActive = false;
        }
      }
    }

    // -----------------------------
    // 🏗 CREATE TENANT
    // -----------------------------
    const tenant = await Tenant.create({
      name,
      phone,
      email,
      address,
      profilePic,
      siteId,
      unitId,
      landlordId,
      addedBy,
      billTo,
      gender,
      dob,
      idProof,
      isActive,
      tenancyStartDate: new Date(),
      parking,
    });

    // -----------------------------
    // 🧾 UPDATE UNIT & HISTORY
    // -----------------------------
    if (isActive) unit.tenantId = tenant._id;

    unit.tenantHistory.push({
      tenantId: tenant._id,
      startDate: tenant.tenancyStartDate,
      addedBy: tenant.addedBy,
      billTo: tenant.billTo,
      isActive: tenant.isActive,
    });

    await unit.save();

    // -----------------------------
    // 👤 CREATE USER
    // -----------------------------
    const password = `${tenant.name.substring(0, 3).toLowerCase()}@123`;

    const createdUser = await createUser({
      name: tenant.name,
      email: tenant.email,
      phone: tenant.phone,
      password,
      role: "tenant",
      referenceId: tenant._id,
      siteId,
      unitId,
    });

    tenant.userId = createdUser._id;
    await tenant.save();

    return sendSuccess(res, "Tenant added successfully", tenant, 201);
  } catch (err) {
    console.error("Add Tenant Error:", err);
    return sendError(res, "Failed to add tenant", 500, err.message);
  }
};

// 🟡 Get Tenants (with filters + pagination + date range + order)
export const getTenants = async (req, res) => {
  try {
    const {
      search,
      siteId,
      projectId,
      landlordId,
      unitId,
      isActive,
      fromDate,
      toDate,
      order = "desc", // optional: "asc" or "desc"
      page = 1,
      limit = 10,
    } = req.query;

    const query = {};

    // ✅ Handle null/undefined safely
    if (siteId && siteId !== "null" && siteId !== "undefined")
      query.siteId = siteId;
    if (projectId && projectId !== "null" && projectId !== "undefined")
      query.projectId = projectId;
    if (landlordId && landlordId !== "null" && landlordId !== "undefined")
      query.landlordId = landlordId;
    if (unitId && unitId !== "null" && unitId !== "undefined")
      query.unitId = unitId;

    if (isActive !== undefined) query.isActive = isActive === "true";

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: "i" } },
        { phone: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
      ];
    }

    // 📅 Filter by Date Range (createdAt)
    if (fromDate || toDate) {
      query.createdAt = {};
      if (fromDate) query.createdAt.$gte = new Date(fromDate);
      if (toDate) {
        const endOfDay = new Date(toDate);
        endOfDay.setHours(23, 59, 59, 999);
        query.createdAt.$lte = endOfDay;
      }
    }

    // 🧾 Sort order (latest first by default)
    const sortOrder = order === "asc" ? 1 : -1;

    const tenants = await Tenant.find(query)
      .populate("siteId  unitId landlordId")
      .skip((page - 1) * limit)
      .limit(Number(limit))
      .sort({ createdAt: sortOrder });

    const total = await Tenant.countDocuments(query);

    return sendSuccess(
      res,
      tenants.length ? "Tenants fetched successfully." : "No tenants found.",
      {
        tenants,
        total,
        page: Number(page),
        limit: Number(limit),
      },
      200
    );
  } catch (err) {
    console.error("Get Tenants Error:", err);
    return sendError(res, "Failed to fetch tenants.", 500, err?.message);
  }
};

// 🟢 Get single Tenant
export const getTenantById = async (req, res) => {
  if (req?.params?.id === undefined || req?.params?.id === null) {
    return sendError(res, "Tenant ID is required", 400, "Tenant ID is missing");
  }
  try {
    const tenant = await Tenant.findById(req.params.id).populate(
      "siteId  unitId landlordId"
    );
    if (!tenant)
      return res
        .status(404)
        .json({ success: false, message: "Tenant not found." });

    res.status(200).json({ success: true, data: tenant });
  } catch (err) {
    console.error("Get Tenant Error:", err);
    res.status(500).json({ success: false, message: "Server Error" });
  }
};

export const updateTenant = async (req, res) => {
  try {
    const tenantId = req.params.id;
    if (!tenantId) return sendError(res, "Tenant ID is required", 400);

    if (Object.keys(req.body).length === 0)
      return sendError(res, "No data provided for update", 400);

    const tenant = await Tenant.findById(tenantId);
    if (!tenant) return sendError(res, "Tenant not found.", 404);

    const { isActive, gender, idProof, dob, ...updates } = req.body;

    const unit = await Unit.findById(tenant.unitId);
    if (!unit) return sendError(res, "Unit not found.", 404);

    // 🔄 DEACTIVATE OTHER ACTIVE TENANTS IF CURRENT TENANT IS ACTIVATED
    if (isActive === true) {
      const otherTenants = await Tenant.find({
        unitId: tenant.unitId,
        _id: { $ne: tenant._id },
        isActive: true,
      });

      for (const other of otherTenants) {
        other.isActive = false;
        other.tenancyEndDate = new Date();
        await other.save();

        // Update the existing tenantHistory entry
        const historyEntry = unit.tenantHistory.find(
          (h) => String(h.tenantId) === String(other._id) && h.isActive === true
        );
        if (historyEntry) {
          historyEntry.endDate = other.tenancyEndDate;
          historyEntry.isActive = false;
        }
      }
    }

    // Apply updates to tenant
    Object.assign(tenant, updates);
    if (isActive !== undefined) tenant.isActive = isActive;
    if (isActive === true && !tenant.tenancyStartDate)
      tenant.tenancyStartDate = new Date();

    await tenant.save();

    // ✅ Update or push tenant history
    let historyEntry = unit.tenantHistory.find(
      (h) => String(h.tenantId) === String(tenant._id) && h.isActive === true
    );

    if (historyEntry) {
      historyEntry.startDate = tenant.tenancyStartDate;
      historyEntry.endDate = tenant.tenancyEndDate || undefined;
      historyEntry.isActive = tenant.isActive;
    } else {
      unit.tenantHistory.push({
        tenantId: tenant._id,
        startDate: tenant.tenancyStartDate,
        endDate: tenant.tenancyEndDate || undefined,
        addedBy: tenant.addedBy,
        billTo: tenant.billTo,
        isActive: tenant.isActive,
      });
    }

    // Update unit tenant reference
    if (isActive === true) unit.tenantId = tenant._id;

    await unit.save();

    return sendSuccess(res, "Tenant updated successfully.", tenant, 200);
  } catch (err) {
    console.error("Update Tenant Error:", err);
    return sendError(res, "Failed to update tenant.", 500, err.message);
  }
};

// 🔴 Delete / Archive Tenant
export const deleteTenant = async (req, res) => {
  try {
    const tenantId = req.params.id;
    if (!tenantId)
      return sendError(res, "Tenant ID is required", 400, "Missing ID");

    const tenant = await Tenant.findById(tenantId);
    if (!tenant) return sendError(res, "Tenant not found.", 404);

    tenant.isActive = false;
    tenant.tenancyEndDate = new Date();
    await tenant.save();

    const unit = await Unit.findById(tenant.unitId);
    if (unit) {
      // Update existing tenant history in unit
      const historyEntry = unit.tenantHistory.find(
        (h) => String(h.tenantId) === String(tenant._id) && h.isActive === true
      );
      if (historyEntry) {
        historyEntry.endDate = tenant.tenancyEndDate;
        historyEntry.isActive = false;
      }

      // Clear unit tenant reference if it's the same tenant
      if (String(unit.tenantId) === String(tenant._id)) {
        unit.tenantId = null;
      }

      await unit.save();
    }

    return sendSuccess(res, "Tenant archived successfully.", tenant, 200);
  } catch (err) {
    console.error("Delete Tenant Error:", err);
    return sendError(res, "Server Error", 500, err.message);
  }
};
