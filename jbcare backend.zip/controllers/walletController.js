import crypto from "crypto";
import { razorpayInstance } from "../models/utilsSchemas/WalletTransactions.modal.js";
import Landlord from "../models/LandLord.modal.js";
import WalletTransaction from "../models/utilsSchemas/WalletTransactions.modal.js";
import Billing from "../models/Billing.modal.js";
import Ledger from "../models/Ledger.modal.js";
import { createLedger } from "./ledgerController.js";
// import { createLedgerEntry, getOpening } from "./ledgerController.js";

// 🧾 Create Razorpay order
export const createOrder = async (req, res) => {
  try {
    const { amount } = req.body;

    if (!amount)
      return res
        .status(400)
        .json({ success: false, message: "Amount is required" });

    const options = {
      amount: amount * 100, // Convert to paise
      currency: "INR",
      receipt: `wallet_${Date.now()}`,
    };

    const order = await razorpayInstance.orders.create(options);

    res.status(200).json({
      success: true,
      orderId: order.id,
      amount: order.amount,
      currency: order.currency,
    });
  } catch (error) {
    console.error("Razorpay Order Error:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to create Razorpay order" });
  }
};

// ✅ Verify payment and credit wallet
export const verifyPayment = async (req, res) => {
  try {
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      amount,
      landlordId,
    } = req.body;

    if (!landlordId)
      return res
        .status(400)
        .json({ success: false, message: "Landlord ID is required" });

    // Verify Razorpay signature
    const body = razorpay_order_id + "|" + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(body)
      .digest("hex");

    if (expectedSignature !== razorpay_signature) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid payment signature" });
    }

    // Update landlord wallet
    const landlord = await Landlord.findById(landlordId);
    if (!landlord)
      return res
        .status(404)
        .json({ success: false, message: "Landlord not found" });

    // 🟢 Add to availableBalance (NOT credit limit)
    landlord.availableBalance =
      (landlord.availableBalance || 0) + Number(amount);

    await landlord.save();

    // Record credit transaction
    await WalletTransaction.create({
      landlordId,
      type: "credit",
      amount,
      description: "Wallet Top-Up via Razorpay",
      referenceId: razorpay_payment_id,
      method: "razorpay",
    });

    res.status(200).json({
      success: true,
      message: "Wallet recharged successfully",
      updatedBalance: landlord.walletBalance,
    });
  } catch (error) {
    console.error("Wallet verification error:", error);
    res.status(500).json({
      success: false,
      message: "Payment verification failed",
      error: error.message,
    });
  }
};

export const payUsingWallet = async (req, res) => {
  try {
    const { landlordId, amount, billId, paidBy, payerId } = req.body;

    const landlord = await Landlord.findById(landlordId);

    // ❗ Check wallet balance
    if (landlord.walletBalance < amount) {
      return res.status(400).json({
        success: false,
        message: "Insufficient wallet balance",
      });
    }

    // 🟦 Deduct wallet amount
    landlord.walletBalance -= amount;
    await landlord.save();

    // ⭐ Create CREDIT ledger entry (payment)
    await createLedger(
      {
        body: {
          landlordId,
          siteId: landlord.siteId, // optional: remove if not needed
          unitId: landlord.unitIds, // optional: remove if not needed
          billId: billId || null,
          amount,
          type:"CREDIT",
          purpose: "Bill Payment",
          transactionType: "Payment", // very important
        },
      },
      {
        status: () => ({ json: () => {} }), // dummy express res
      }
    );

    // ⭐ Mark bill paid (if bill exists)
    if (billId) {
      await Billing.findByIdAndUpdate(
        billId,
        {
          status: "Paid",
          paidOn: new Date(),
          paidBy,
          payerId,
        },
        { new: true }
      );
    }

    return res.status(200).json({
      success: true,
      message: "Payment processed successfully",
      walletBalance: landlord.walletBalance,
    });
  } catch (error) {
    console.error("❌ Wallet Debit Error:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to process payment",
      error: error.message,
    });
  }
};

// 📜 Get wallet history (Balance + All Transactions)
export const getWalletHistory = async (req, res) => {
  try {
    const { landlordId } = req.params;

    if (!landlordId) {
      return res.status(400).json({
        success: false,
        message: "Landlord ID is required",
      });
    }

    // Fetch landlord wallet balances
    const landlord = await Landlord.findById(landlordId).select(
      "walletBalance availableBalance"
    );

    if (!landlord) {
      return res.status(404).json({
        success: false,
        message: "Landlord not found",
      });
    }

    // Fetch all transactions
    const transactions = await WalletTransaction.find({ landlordId })
      .sort({ createdAt: -1 })
      .lean();

    res.status(200).json({
      success: true,
      wallet: {
        creditLimit: landlord.walletBalance,
        availableBalance: landlord.availableBalance,
        totalUsable: landlord.walletBalance + landlord.availableBalance,
      },
      transactions,
    });
  } catch (error) {
    console.error("Get wallet history error:", error);
    res.status(500).json({
      success: false,
      message: "Failed to get wallet history",
      error: error.message,
    });
  }
};
