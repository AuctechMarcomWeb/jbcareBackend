import Warehouse from "../../models/masters/Warehouse.modal.js";

export const createWarehouse = async (req, res) => {
  try {
    const { sites } = req.body;

    // Ensure sites is always an array
    if (sites && !Array.isArray(sites)) {
      return res.status(400).json({
        success: false,
        message: "sites must be an array",
      });
    }
    const w = new Warehouse(req.body);
    await w.save();
    res.status(201).json({ success: true, data: w });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

export const getWarehouses = async (req, res) => {
  try {
    const {
      search,
      page = 1,
      limit = 10,
      isPagination = "true",
      siteId,
    } = req.query;

    const filter = { isDeleted: false };

    if (siteId) {
      filter.sites = siteId;
    }

    // 🔍 Search by name OR address
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: "i" } },
        { address: { $regex: search, $options: "i" } },
        { sites: { $regex: search, $options: "i" } },
      ];
    }

    // 📌 Default pagination values
    let skip = (page - 1) * limit;

    // 📌 Total warehouses count based on filter
    const totalRecords = await Warehouse.countDocuments(filter);
    const totalPages = Math.ceil(totalRecords / limit);

    let list;

    // ⚡ If pagination = false → return full data
    if (isPagination === "false") {
      list = await Warehouse.find(filter).sort({ name: 1 }).populate("sites");

      return res.json({
        success: true,
        data: list,
        page: null,
        limit: null,
        totalRecords: list.length,
        totalPages: 1,
      });
    }

    // ⚡ If pagination = true → use skip & limit
    list = await Warehouse.find(filter)
      .sort({ name: 1 })
      .skip(skip)
      .limit(Number(limit))
      .populate("sites");

    return res.json({
      success: true,
      data: list,

      page: Number(page),
      limit: Number(limit),
      totalRecords,
      totalPages,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Something went wrong",
      error: error.message,
    });
  }
};

export const updateWarehouse = async (req, res) => {
  const updated = await Warehouse.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  if (!updated)
    return res.status(404).json({ success: false, message: "Not found" });
  res.json({ success: true, data: updated });
};

export const deleteWarehouse = async (req, res) => {
  try {
    const warehouse = await Warehouse.findByIdAndUpdate(
      req.params.id,
      { isDeleted: true },
      { new: true }
    );

    if (!warehouse) {
      return res.status(404).json({
        success: false,
        message: "Warehouse not found",
      });
    }

    return res.json({
      success: true,
      message: "Warehouse deleted (soft delete applied)",
      data: warehouse,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Something went wrong",
      error: error.message,
    });
  }
};
